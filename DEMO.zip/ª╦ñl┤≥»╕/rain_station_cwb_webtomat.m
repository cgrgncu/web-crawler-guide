clear;clc;close all
%--------------------------------------------------------------------------
station_id='466930';
station_name='�ˤl��';
station_name_urlencode=urlencode(urlencode(station_name));%�����D�������H���nurlencode�⦸...
target_start_date_str='2021-01-01';
target_end_date_str='2021-02-28';
    %--
    disp('�}�l...')
    %--
    for i_datenumber=datenum(target_start_date_str):datenum(target_end_date_str)
        target_date_str=datestr(i_datenumber,'yyyy-mm-dd');
        %--
        % �إ߿�X��Ƨ�
        output_folder=[station_id,'\',target_date_str(1:4),'\',station_id];
        if exist(output_folder,'dir')~=7
            mkdir(output_folder)
        end
        % �ǳƿ�X�ɦW
        output_mat_file_name=[output_folder,'\',strrep(target_date_str,'-',''),'_',station_id,'.mat'];
        %--
        Weather.StationID=station_id;
        Weather.StationName=station_name;
        Weather.Date=target_date_str;
        % �U��
        if (exist(output_mat_file_name,'file')==2)
            disp('�ɮצs�b,skip!')
        else        
            disp(target_date_str)
            temp_char = urlread(['http://e-service.cwb.gov.tw/HistoryDataQuery/DayDataController.do?command=viewMain&station=',station_id,'&stname=',station_name_urlencode,'&datepicker=',target_date_str,'&altitude=0m']);
            return
            %--------------------------------------------------------------------------
            % �T�{��Ʀ��X�p�ɡA����@�����Ӧ�24�p��
            temp_str='</tr>';
            temp_index=strfind(temp_char,temp_str);
            hour_count=length(temp_index)-4;
            %--------------------------------------------------------------------------
            %--------------------------------------------------------------------------
            % ���X<tr class="second_tr"> ~ </tr>
            % --
            % ��}�Y
            temp_str='<tr class="first_tr">';
            temp_start_index=strfind(temp_char,temp_str);
            % �h���e����
            temp_char=temp_char(temp_start_index(1):end);
            % �䵲��
            temp_str='</tr>';
            temp_end_index=strfind(temp_char,temp_str);
            temp_target_char=temp_char(1:temp_end_index(1)+length(temp_str)-1);
            % �h���e����
            temp_char=temp_char(temp_end_index(1)+length(temp_str):end);
            %--
            % ���R
            temp_th_start_index=strfind(temp_target_char,'<th');
            temp_th_end_index=strfind(temp_target_char,'</th>');
            if length(temp_th_start_index)==length(temp_th_end_index)
                temp_vertical_column_count=length(temp_th_start_index);
                %disp(['���ƶq=',num2str(temp_vertical_column_count)])
            else
                disp('���~!<th>�P</th>�ƶq���P!')
                temp_vertical_column_count=0;
                return
            end
            %--
            % �g�J��Ƽ��Y
            for i=1:temp_vertical_column_count
                %disp(temp_target_char(temp_th_start_index(i)+length('<tr>'):temp_th_end_index(i)-1))   
                temp_str=temp_target_char(temp_th_start_index(i):temp_th_end_index(i)-1);
                temp_str=strrep(temp_str,'<th>','');
                temp_str=strrep(temp_str,'<br>','');        
                Weather.DataHeader{1,i}=temp_str;
            end
            %--------------------------------------------------------------------------
            %--------------------------------------------------------------------------
            % ���X<tr class="second_tr"> ~ </tr>
            % --
            % ��}�Y
            temp_str='<tr class="second_tr">';
            temp_start_index=strfind(temp_char,temp_str);
            % �h���e����
            temp_char=temp_char(temp_start_index(1):end);
            % �䵲��
            temp_str='</tr>';
            temp_end_index=strfind(temp_char,temp_str);
            temp_target_char=temp_char(1:temp_end_index(1)+length(temp_str)-1);
            % �h���e����
            temp_char=temp_char(temp_end_index(1)+length(temp_str):end);
            %--
            % ���R
            temp_th_start_index=strfind(temp_target_char,'<th>');
            temp_th_end_index=strfind(temp_target_char,'</th>');
            if length(temp_th_start_index)==length(temp_th_end_index)
                temp_vertical_column_count=length(temp_th_start_index);
                %disp(['���ƶq=',num2str(temp_vertical_column_count)])
            else
                disp('���~!<th>�P</th>�ƶq���P!')
                temp_vertical_column_count=0;
                return
            end
            %--
            % �g�J��Ƽ��Y
            for i=1:temp_vertical_column_count
                %disp(temp_target_char(temp_th_start_index(i)+length('<tr>'):temp_th_end_index(i)-1))   
                temp_str=temp_target_char(temp_th_start_index(i):temp_th_end_index(i)-1);
                temp_str=strrep(temp_str,'<th>','');
                temp_str=strrep(temp_str,'<br>','');        
                Weather.DataHeader2{1,i}=temp_str;
            end
            %--------------------------------------------------------------------------
            %--------------------------------------------------------------------------
            for i_loop=1:hour_count
                %--------------------------------------------------------------------------
                % ���X<tr class="second_tr"> ~ </tr>
                % --
                % ��}�Y
                temp_str='<tr>';
                temp_start_index=strfind(temp_char,temp_str);
                % �h���e����
                temp_char=temp_char(temp_start_index(1):end);
                % �䵲��
                temp_str='</tr>';
                temp_end_index=strfind(temp_char,temp_str);
                temp_target_char=temp_char(1:temp_end_index(1)+length(temp_str)-1);
                % �h���e����
                temp_char=temp_char(temp_end_index(1)+length(temp_str):end);
                %--
                % ���R
                temp_th_start_index=strfind(temp_target_char,'<td');
                temp_th_end_index=strfind(temp_target_char,'</td>');
                if length(temp_th_start_index)==length(temp_th_end_index)
                    temp_vertical_column_count=length(temp_th_start_index);
                    %disp(['���ƶq=',num2str(temp_vertical_column_count)])
                else
                    disp('���~!<th>�P</th>�ƶq���P!')
                    temp_vertical_column_count=0;
                    return
                end
                %--
                % �g�J��Ƽ��Y
                for i=1:temp_vertical_column_count
                    %disp(temp_target_char(temp_th_start_index(i):temp_th_end_index(i)-1))   
                    temp_str=temp_target_char(temp_th_start_index(i):temp_th_end_index(i)-1);
                    temp_str=strrep(temp_str,'<td nowrap>','');
                    temp_str=strrep(temp_str,'<td>','');
                    temp_str=strrep(temp_str,'&nbsp;','');        
                    Weather.Data{i_loop,i}=temp_str;
                end
                %--------------------------------------------------------------------------
            end
            %--------------------------------------------------------------------------        
            % �s��        
            save(output_mat_file_name,'Weather')
            %--------------------------------------------------------------------------
        end
    end
    disp('����!')