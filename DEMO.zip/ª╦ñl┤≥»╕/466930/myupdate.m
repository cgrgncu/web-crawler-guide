function txt = myupdate(src, event)
pos = get(event,'Position');
txt = {['Date: ' datestr(pos(1), 'yyyy-mm-dd HH')], ...
    ['Value: ' num2str(pos(2))]};