clear;clc;close all
%--------------------------------------------------------------------------
temp_data=load('2017_466930.mat');
Target_Weathers=temp_data.Weathers;

% ��B�q
subplot(3,1,1)    
[temp_axes,temp_plotyy_handle1,temp_plotyy_handle2]=plotyy(Target_Weathers.OneDay.Data(:,1),Target_Weathers.OneDay.Data(:,3),Target_Weathers.OneDay.Data(:,1),Target_Weathers.OneDay.Data(:,4),'bar','plot');
% �H�U�n�_�ǡA���Ǧ��v�T...
datetick(temp_axes(1),'x', 'yyyy-mm-dd')
datetick(temp_axes(2),'x','')
temp_date_tick = datenum([
['2017-01-01']
['2017-02-01']
['2017-03-01']
['2017-04-01']
['2017-05-01']
['2017-06-01']
['2017-07-01']
['2017-08-01']
['2017-09-01']
['2017-10-01']
['2017-11-01']
['2017-12-01']
],'yyyy-mm-dd');
set(temp_axes(1), 'xtick', temp_date_tick);
set(temp_axes(1), 'xticklabel', datestr(temp_date_tick,'yyyy-mm-dd'));
set(temp_axes(1),'TickDir','out')
set(temp_axes(2), 'xtick', []);
set(temp_axes(2),'TickDir','out')
box(temp_axes(1),'off')
xlim(temp_axes(1),[min(Target_Weathers.OneDay.Data(:,1)),max(Target_Weathers.OneDay.Data(:,1))])
xlim(temp_axes(2),[min(Target_Weathers.OneDay.Data(:,1)),max(Target_Weathers.OneDay.Data(:,1))])
set(temp_plotyy_handle2,'color','red')
set(temp_axes(2),'YColor','red')
title([Target_Weathers.DateFrom,'~',Target_Weathers.DateTo,' ',Target_Weathers.StationName,' ��B�q�ū�' ])
%--
% �|�p�ɫB�q    
subplot(3,1,2)    
bar(Target_Weathers.FourHour.Data(:,1),Target_Weathers.FourHour.Data(:,3))
hold on
plot(Target_Weathers.FourHour.Data(:,1),Target_Weathers.FourHour.Data(:,4),'r-')
datetick('x', 'yyyy-mm-dd')
xlim([min(Target_Weathers.OneDay.Data(:,1)),max(Target_Weathers.OneDay.Data(:,1))])
title([Target_Weathers.DateFrom,'~',Target_Weathers.DateTo,' ',Target_Weathers.StationName,' �|�p�ɫB�q�ū�' ])

% �@�p�ɫB�q   
subplot(3,1,3)    
bar(Target_Weathers.OneHour.Data(:,1),Target_Weathers.OneHour.Data(:,3))
hold on
plot(Target_Weathers.OneHour.Data(:,1),Target_Weathers.OneHour.Data(:,4),'r-')
datetick('x', 'yyyy-mm-dd')
xlim([min(Target_Weathers.OneDay.Data(:,1)),max(Target_Weathers.OneDay.Data(:,1))])
title([Target_Weathers.DateFrom,'~',Target_Weathers.DateTo,' ',Target_Weathers.StationName,' �@�p�ɫB�q�ū�' ])

dcm = datacursormode(gcf);
dcm.Enable = 'on';
dcm.UpdateFcn = @myupdate;