clear;clc;close all
%--------------------------------------------------------------------------
station_id='466930';
station_name='�ˤl��';

target_year='2020';
    target_start_date_str=[target_year,'-01-01'];
    target_end_date_str=[target_year,'-04-30'];
    
    Target_Weathers.StationID=station_id;
    Target_Weathers.StationName=station_name;
    Target_Weathers.DateFrom=target_start_date_str;
    Target_Weathers.DateTo=target_end_date_str;
    %-------------------------------------------------
    % ��z��B�q�P�ūסA�N�L�qT�w�q���B�q0�A�L��Ƭ�NaN�A�̤p�ɶ����j��찲�]������
    %--
    Target_Weathers.OneDay.DataHeader={'DayNumber_From','DayNumber_To','��ֿn�����q(mm)','�饭�����(�J)'};
	% --
    temp_index=0;
    for i_datenumber=datenum(target_start_date_str):datenum(target_end_date_str)
        target_date_str=datestr(i_datenumber,'yyyymmdd');
        %disp([target_date_str(1:4),'\',station_id,'\',target_date_str,'_',station_id,'.mat'])
        mat_file_name=[target_date_str(1:4),'\',station_id,'\',target_date_str,'_',station_id,'.mat'];
        if (exist(mat_file_name,'file')==2)
            temp_index=temp_index+1;
            Target_Weathers.OneDay.Data(temp_index,1)=i_datenumber;
            Target_Weathers.OneDay.Data(temp_index,2)=i_datenumber-1/24/60;
            temp_data=load(mat_file_name);
            %--
            % �B�q
            temp_data2=temp_data.Weather.Data(:,11);
            % T���ܷL�q�A�]�w��0
            temp_data2=strrep(temp_data2,'T','0.0');
            % ���r�ର�ƭȡA�p�G�L�k�ഫ�h��NaN
            temp_data2=str2double(temp_data2);
            % �p�G24�p�ɦ�8�p�ɳ�NaN�N���@���NaN�A�p�G8�p�ɥH�U�N�����ƭȪ����`�M
            if (sum(isnan(temp_data2)) >= 8)
                Target_Weathers.OneDay.Data(i_datenumber-datenum(target_start_date_str)+1,3)=NaN;
            elseif (length(temp_data2) == 24)
                temp_data2(isnan(temp_data2))=[];
                %disp(length(temp_data2))
                if ~isempty(temp_data2)
                    Target_Weathers.OneDay.Data(i_datenumber-datenum(target_start_date_str)+1,3)=sum(temp_data2);
                else
                    Target_Weathers.OneDay.Data(i_datenumber-datenum(target_start_date_str)+1,3)=NaN;  
                end
            else
                Target_Weathers.OneDay.Data(i_datenumber-datenum(target_start_date_str)+1,3)=NaN;            
            end
            %--
            % �ū�
            temp_data2=temp_data.Weather.Data(:,4);
            % T���ܷL�q�A�]�w��0
            temp_data2=strrep(temp_data2,'T','0.0');
            % ���r�ର�ƭȡA�p�G�L�k�ഫ�h��NaN
            temp_data2=str2double(temp_data2);
            % �p�G24�p�ɦ�8�p�ɳ�NaN�N���@���NaN�A�p�G8�p�ɥH�U�N�����ƭȪ����`�M
            if (sum(isnan(temp_data2)) >= 8)
                Target_Weathers.OneDay.Data(i_datenumber-datenum(target_start_date_str)+1,4)=NaN;
            elseif (length(temp_data2) == 24)
                temp_data2(isnan(temp_data2))=[];
                %disp(length(temp_data2))
                if ~isempty(temp_data2)
                    Target_Weathers.OneDay.Data(i_datenumber-datenum(target_start_date_str)+1,4)=mean(temp_data2);
                else
                    Target_Weathers.OneDay.Data(i_datenumber-datenum(target_start_date_str)+1,4)=NaN;  
                end
            else
                Target_Weathers.OneDay.Data(i_datenumber-datenum(target_start_date_str)+1,4)=NaN;            
            end
            %--
        else
            disp([mat_file_name,'�ɮפ��s�b!return!'])
            return
        end
    end
    %-------------------------------------------------
    
    %-------------------------------------------------
    % ��z4�p�ɫB�q�P�ūסA�N�L�qT�w�q���B�q0�A�L��Ƭ�NaN
    % 
    Target_Weathers.FourHour.DataHeader={'DayNumber_From','DayNumber_To','�|�p�ɲֿn�����q(mm)','�|�p�ɥ������(�J)'};
    temp_index=0;
    range_in_hour=4;
    for i_datenumber=datenum(target_start_date_str):datenum(target_end_date_str)
        target_date_str=datestr(i_datenumber,'yyyymmdd');
        %disp([target_date_str(1:4),'\',station_id,'\',target_date_str,'_',station_id,'.mat'])
        mat_file_name=[target_date_str(1:4),'\',station_id,'\',target_date_str,'_',station_id,'.mat'];
        if (exist(mat_file_name,'file')==2)
            temp_data=load(mat_file_name);
            if length(temp_data.Weather.Data(:,1))==24
                for i_hour=1:24
                    if mod(i_hour,range_in_hour)==0
                        temp_index=temp_index+1;
                        %disp([target_date_str,sprintf('%02d00',i_hour-range_in_hour),'~',target_date_str,sprintf('%02d59',i_hour-1)])
                        Target_Weathers.FourHour.Data(temp_index,1)=datenum([target_date_str,sprintf('%02d00',i_hour-range_in_hour)],'yyyymmddHHMM');
                        Target_Weathers.FourHour.Data(temp_index,2)=datenum([target_date_str,sprintf('%02d59',i_hour-1)],'yyyymmddHHMM'); 
                        %--
                        % �B�q
                        temp_data2=temp_data.Weather.Data(i_hour-range_in_hour+1:i_hour,11);
                        % T���ܷL�q�A�]�w��0
                        temp_data2=strrep(temp_data2,'T','0.0');
                        % ���r�ର�ƭȡA�p�G�L�k�ഫ�h��NaN
                        temp_data2=str2double(temp_data2);
                        %
                        temp_data2(isnan(temp_data2))=[];
                        if ~isempty(temp_data2)
                            Target_Weathers.FourHour.Data(temp_index,3)=sum(temp_data2);
                        else
                            Target_Weathers.FourHour.Data(temp_index,3)=NaN;            
                        end
                        %--
                        % �ū�
                        temp_data2=temp_data.Weather.Data(i_hour-range_in_hour+1:i_hour,4);
                        % ���r�ର�ƭȡA�p�G�L�k�ഫ�h��NaN
                        temp_data2=str2double(temp_data2);
                        %
                        temp_data2(isnan(temp_data2))=[];
                        if ~isempty(temp_data2)
                            Target_Weathers.FourHour.Data(temp_index,4)=mean(temp_data2);
                        else
                            Target_Weathers.FourHour.Data(temp_index,4)=NaN;            
                        end
                        %--
                    end
                end
            else
                disp('���~!�ӤѤ��O24�p��!return!')
                return
            end               
        else
            disp([mat_file_name,'�ɮפ��s�b!return!'])
            return
        end
    end
    %-------------------------------------------------    
    %-------------------------------------------------
    % ��z1�p�ɫB�q�P�ūסA�N�L�qT�w�q���B�q0�A�L��Ƭ�NaN
    % 
    Target_Weathers.OneHour.DataHeader={'DayNumber_From','DayNumber_To','�@�p�ɲֿn�����q(mm)','�@�p�ɥ������(�J)'};
    temp_index=0;
    range_in_hour=1;
    for i_datenumber=datenum(target_start_date_str):datenum(target_end_date_str)
        target_date_str=datestr(i_datenumber,'yyyymmdd');
        %disp([target_date_str(1:4),'\',station_id,'\',target_date_str,'_',station_id,'.mat'])
        mat_file_name=[target_date_str(1:4),'\',station_id,'\',target_date_str,'_',station_id,'.mat'];
        if (exist(mat_file_name,'file')==2)
            temp_data=load(mat_file_name);
            if length(temp_data.Weather.Data(:,1))==24
                for i_hour=1:24
                    temp_index=temp_index+1;
                    %disp([target_date_str,sprintf('%02d00',i_hour-range_in_hour),'~',target_date_str,sprintf('%02d59',i_hour-1)])                    
                    Target_Weathers.OneHour.Data(temp_index,1)=datenum([target_date_str,sprintf('%02d00',i_hour-range_in_hour)],'yyyymmddHHMM');                      
                    Target_Weathers.OneHour.Data(temp_index,2)=datenum([target_date_str,sprintf('%02d59',i_hour-1)],'yyyymmddHHMM');                    
                    %--
                    % �B�q
                    temp_data2=temp_data.Weather.Data(i_hour,11);
                    % T���ܷL�q�A�]�w��0
                    temp_data2=strrep(temp_data2,'T','0.0');
                    % ���r�ର�ƭȡA�p�G�L�k�ഫ�h��NaN
                    temp_data2=str2double(temp_data2);
                    %
                    temp_data2(isnan(temp_data2))=[];
                    if ~isempty(temp_data2)
                        Target_Weathers.OneHour.Data(temp_index,3)=temp_data2;
                    else
                        Target_Weathers.OneHour.Data(temp_index,3)=NaN;            
                    end
                    %--
                    % �ū�
                    temp_data2=temp_data.Weather.Data(i_hour,4);
                    % ���r�ର�ƭȡA�p�G�L�k�ഫ�h��NaN
                    temp_data2=str2double(temp_data2);
                    %
                    temp_data2(isnan(temp_data2))=[];
                    if ~isempty(temp_data2)
                        Target_Weathers.OneHour.Data(temp_index,4)=temp_data2;
                    else
                        Target_Weathers.OneHour.Data(temp_index,4)=NaN;            
                    end
                    %--
                end
            else
                disp('���~!�ӤѤ��O24�p��!return!')
                return
            end               
        else
            disp([mat_file_name,'�ɮפ��s�b!return!'])
            return
        end
    end
    %-------------------------------------------------
    %save('Target_Weathers.mat','Target_Weathers')
    Weathers=Target_Weathers;
    %-------------------------------------------------
    save([target_year,'_',station_id,'.mat'],'Weathers')
% subplot(3,1,1)    
% bar(Target_Weathers.FourHour.Data(:,1),Target_Weathers.FourHour.Data(:,3))
% hold on
% plot(Target_Weathers.FourHour.Data(:,1),Target_Weathers.FourHour.Data(:,4),'.-')
% plot(Target_Weathers.OneDay.Data(:,1),Target_Weathers.OneDay.Data(:,4),'r.-')
% plot(Target_Weathers.OneHour.Data(:,1),Target_Weathers.OneHour.Data(:,4),'g.-')
% datetick('x', 'yyyy-mm-dd')
% xlim([min(Target_Weathers.FourHour.Data(:,1)),max(Target_Weathers.FourHour.Data(:,1))])
% dcm = datacursormode(gcf);
% dcm.Enable = 'on';
% dcm.UpdateFcn = @myupdate;
    %
% subplot(3,1,2)    
% bar(Target_Weathers.OneDay.Data(:,1),Target_Weathers.OneDay.Data(:,3))
% hold on
% plot(Target_Weathers.OneDay.Data(:,1),Target_Weathers.OneDay.Data(:,4),'.-')
% subplot(3,1,3)    
% bar(Target_Weathers.OneHour.Data(:,1),Target_Weathers.OneHour.Data(:,3))
% hold on
% plot(Target_Weathers.OneHour.Data(:,1),Target_Weathers.OneHour.Data(:,4),'.-')
